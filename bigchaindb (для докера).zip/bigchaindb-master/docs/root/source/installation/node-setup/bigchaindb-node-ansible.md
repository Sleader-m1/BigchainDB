# Setting up a network of nodes with the Ansible script 

You can find one of the installation methods with Ansible on GitHub at:

[Ansible script](https://github.com/bigchaindb/bigchaindb-node-ansible)

It allows to install BigchainDB, MongoDB, Tendermint, and python, and then connect nodes into a network. Current tested machine is Ubuntu 18.04. 